import { AnothertestPage } from './app.po';

describe('anothertest App', () => {
  let page: AnothertestPage;

  beforeEach(() => {
    page = new AnothertestPage();
  });

  it('should display welcome message', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('Welcome to app!');
  });
});
