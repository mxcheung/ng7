export const environment = {
  production: true,
  build_number: 'uncontrolled build'
};
